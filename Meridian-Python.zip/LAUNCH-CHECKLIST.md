# Meridian launch requirements

This private review version contains all nine main pages and six legal status pages. Form entries can be downloaded locally; nothing is submitted to Meridian. No fabricated articles, team biographies, credentials or contact details are published.

Before public launch:
- Supply logo and approved brand colours.
- Confirm current regulatory wording, appointed insurer and reinsurance statements.
- Supply leadership photos, biographies, qualifications and LinkedIn URLs.
- Supply partnership contact, address, telephone, email, WhatsApp and company LinkedIn URL.
- Supply Cardinal 360 partner portal URL.
- Approve legal documents, including POPIA notices and consent language.
- Connect a secure enquiry service with spam protection, delivery monitoring and server validation. Replace the local download workflow only after successful end-to-end delivery testing.
- Supply approved articles and accessible brochure PDFs. Add article templates, brochure request delivery and any marketing opt-in only when content and privacy requirements are approved.
- Confirm domain and update canonical metadata, sitemap and social sharing assets.
- Review product wording and any external claims before publication.

Content, styles and interactions are all embedded in app.py. Set SITE_URL to the confirmed domain when hosting.
