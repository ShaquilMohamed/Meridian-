# Meridian Underwriting Managers

The complete Meridian website, converted to a Python Flask application.
**Everything is in one folder. All website pages, styling and browser interactions are inside `app.py`. There are no templates, static folders or nested page directories to upload.**

## Upload to GitHub

1. Extract `Meridian-Python.zip`.
2. Open the extracted `Meridian-Python` folder.
3. In an empty GitHub repository, choose **Add file → Upload files**.
4. Drag all the files from inside this folder onto the upload page, then commit.

The repository should show `app.py`, `requirements.txt`, `Procfile`, `README.md` and `LAUNCH-CHECKLIST.md` at its top level. The optional hidden `.gitignore` file can be added separately if your file picker does not show it. Do not upload the ZIP itself.

## What each file does

- `app.py` — the entire website and Python server.
- `requirements.txt` — the two Python dependencies.
- `Procfile` — the production startup command for compatible Python hosts.
- `LAUNCH-CHECKLIST.md` — business details still required before a complete launch.
- `.gitignore` — keeps local caches and private environment files out of GitHub.

## Run on your computer

Use Python 3.10 or newer. Open a terminal in this folder:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:8000**. Stop with Ctrl+C.

On Windows, use `py -m venv .venv`, then `.venv\Scripts\activate`, followed by the same `python` commands. The local development server works on Windows; Gunicorn production hosting requires Linux or another supported Unix system.

## Publish with a Python host

GitHub stores the files. GitHub Pages cannot run Python applications.

Connect the repository to a hosting service that supports Python/Flask, then use:

- Build/install command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --access-logfile -`
- Root directory: repository root (leave blank if the host allows it)
- Health check path: `/health`

The host must provide a `PORT` environment variable, or you can set it to the port the host requires. The included `Procfile` provides the same start command for hosts that recognise it. Use the host's HTTPS endpoint; do not use Flask's local development server for public hosting.

When your domain is ready, set `SITE_URL` to the domain origin, for example `https://www.your-domain.co.za`, with no path after the domain. This updates canonical URLs, sharing metadata and sitemap links. If it is unset, the app uses the request's domain.

## Editing and current limits

Open `app.py` to edit the page HTML in `PAGES` or the CSS and JavaScript in `ASSETS`. No generator, image directory or build tool is needed. Fonts load from Google Fonts, with local fallbacks when unavailable.

All nine main pages and six legal status pages are included. The design and existing interactions are preserved. No platform attribution is added to the website.

The enquiry form still downloads a file locally; it does not send enquiries to Meridian. Contact details, WhatsApp, partner portal, team profiles, approved legal documents, articles and brochures still need to be supplied or connected. See `LAUNCH-CHECKLIST.md`.

This is an independent copy. Uploading or changing this repository does not update the existing hosted website automatically.
